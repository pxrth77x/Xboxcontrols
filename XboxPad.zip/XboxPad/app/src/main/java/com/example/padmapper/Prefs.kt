package com.example.padmapper

import android.app.AppOpsManager
import android.content.Context
import android.os.Process

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("pad", Context.MODE_PRIVATE)
    fun apps(c: Context): Set<String> = HashSet(sp(c).getStringSet("apps", emptySet()) ?: emptySet())
    fun setApps(c: Context, s: Set<String>) { sp(c).edit().putStringSet("apps", HashSet(s)).apply() }
    fun hasUsage(c: Context): Boolean {
        val ao = c.getSystemService(AppOpsManager::class.java)
        return ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }
}
