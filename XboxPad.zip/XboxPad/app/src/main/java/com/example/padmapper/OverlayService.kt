package com.example.padmapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast

class OverlayService : Service() {
    companion object {
        const val START = "start"; const val STOP = "stop"; const val TOGGLE = "toggle"
        @Volatile var running = false

        private fun nm(c: Context): NotificationManager {
            val m = c.getSystemService(NotificationManager::class.java)
            m.createNotificationChannel(NotificationChannel("pad", "Gamepad", NotificationManager.IMPORTANCE_LOW))
            return m
        }

        private fun pi(c: Context, a: String): PendingIntent {
            val i = Intent(c, OverlayService::class.java).setAction(a)
            val f = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            return if (a == START) PendingIntent.getForegroundService(c, 1, i, f)
            else PendingIntent.getService(c, a.hashCode(), i, f)
        }

        private fun act(c: Context, icon: Int, label: String, a: String) =
            Notification.Action.Builder(Icon.createWithResource(c, icon), label, pi(c, a)).build()

        fun postOff(c: Context) {
            val n = Notification.Builder(c, "pad")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Xbox Pad is off")
                .setContentText("Tap Start to show the pad in your chosen apps")
                .addAction(act(c, android.R.drawable.ic_media_play, "Start", START))
                .setOngoing(true).build()
            nm(c).notify(2, n)
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var pad: PadView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var hidden = false
    private var fg: String? = null
    private var fgCls: String? = null
    private var lastEv = 0L
    private val tick = object : Runnable { override fun run() { poll(); h.postDelayed(this, 1000) } }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            STOP -> stopAll()
            TOGGLE -> toggle()
            else -> start()
        }
        return START_NOT_STICKY
    }

    private fun start() {
        if (running) return
        nm(this).cancel(2)
        val n = Notification.Builder(this, "pad")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Xbox Pad is on")
            .setContentText("Shows only in your chosen apps")
            .addAction(act(this, android.R.drawable.ic_menu_view, "Hide / show", TOGGLE))
            .addAction(act(this, android.R.drawable.ic_delete, "Stop", STOP))
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (!Settings.canDrawOverlays(this) || !Prefs.hasUsage(this) || !Injector.ready()) {
            Toast.makeText(this, "Allow Shizuku, overlay and usage access first", Toast.LENGTH_LONG).show()
            stopAll(); return
        }
        running = true
        wm = getSystemService(WindowManager::class.java)
        h.post(tick)
    }

    private fun poll() {
        val um = getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        if (lastEv == 0L) lastEv = now - 12 * 3600_000L
        val ev = um.queryEvents(lastEv + 1, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            lastEv = maxOf(lastEv, e.timeStamp)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) { fg = e.packageName; fgCls = e.className }
            else if (e.eventType == UsageEvents.Event.ACTIVITY_PAUSED && e.packageName == fg && e.className == fgCls) fg = null
        }
        val want = fg != null && fg in Prefs.apps(this)
        if (want && pad == null) attach() else if (!want && pad != null) detach()
    }

    private fun attach() {
        val l = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        if (hidden) l.flags = l.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val v = PadView(this)
        v.alpha = if (hidden) 0f else 1f
        wm?.addView(v, l)
        pad = v; lp = l
    }

    private fun detach() {
        pad?.let { it.release(); try { wm?.removeView(it) } catch (_: Throwable) {} }
        pad = null
    }

    private fun toggle() {
        hidden = !hidden
        val l = lp ?: return
        val v = pad ?: return
        if (hidden) {
            v.release(); v.alpha = 0f
            l.flags = l.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            v.alpha = 1f
            l.flags = l.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
        wm?.updateViewLayout(v, l)
    }

    private fun stopAll() {
        h.removeCallbacks(tick)
        detach()
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        postOff(this)
        stopSelf()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        detach()
        running = false
        super.onDestroy()
    }
}
