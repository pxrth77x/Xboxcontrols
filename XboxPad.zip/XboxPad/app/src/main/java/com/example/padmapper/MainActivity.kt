package com.example.padmapper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val binderL = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 3, pad, pad) }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, pad) }
        root.addView(status)
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        btn("Allow Shizuku access") {
            if (Shizuku.pingBinder()) Shizuku.requestPermission(1)
            else toast("Start Shizuku first")
        }
        btn("Allow drawing over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Allow usage access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        btn("Choose apps") { startActivity(Intent(this, AppPickerActivity::class.java)) }
        btn("Start gamepad") {
            when {
                !Injector.ready() -> toast("Shizuku access is missing")
                !Settings.canDrawOverlays(this) -> toast("Allow drawing over other apps first")
                !Prefs.hasUsage(this) -> toast("Allow usage access first")
                Prefs.apps(this).isEmpty() -> toast("Choose at least one app")
                else -> {
                    startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.START))
                    moveTaskToBack(true)
                }
            }
        }
        btn("Stop gamepad") { startService(Intent(this, OverlayService::class.java).setAction(OverlayService.STOP)) }
        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addRequestPermissionResultListener(permL)
    }

    override fun onResume() {
        super.onResume()
        refresh()
        if (!OverlayService.running) OverlayService.postOff(this)
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeRequestPermissionResultListener(permL)
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun refresh() {
        val s = when {
            !Shizuku.pingBinder() -> "Shizuku: not running"
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> "Shizuku: needs access"
            else -> "Shizuku: ready"
        }
        fun yn(b: Boolean) = if (b) "allowed" else "not allowed"
        status.text = s +
            "\nDraw over other apps: " + yn(Settings.canDrawOverlays(this)) +
            "\nUsage access: " + yn(Prefs.hasUsage(this)) +
            "\nChosen apps: " + Prefs.apps(this).size
    }
}
