package com.example.padmapper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class AppPickerActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val chosen = Prefs.apps(this).toMutableSet()
        val lv = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            adapter = ArrayAdapter(this@AppPickerActivity, android.R.layout.simple_list_item_multiple_choice, apps.map { it.first })
            apps.forEachIndexed { i, a -> setItemChecked(i, a.second in chosen) }
            setOnItemClickListener { _, _, i, _ ->
                if (isItemChecked(i)) chosen += apps[i].second else chosen -= apps[i].second
                Prefs.setApps(this@AppPickerActivity, chosen)
            }
        }
        setContentView(lv)
    }
}
