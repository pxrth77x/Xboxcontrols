# Xbox Pad (Shizuku, no root)

On-screen Xbox controller that sends real gamepad events through Shizuku. It shows only
in the apps you choose, and a notification starts, stops and hides it.

Setup: start Shizuku, open Xbox Pad, allow Shizuku, drawing over apps and usage access,
choose your games, tap Start gamepad.
